var buttonTag;
var numero;
var messaggio;
var card;

numero = document.getElementById("numero");
buttonTag = document.getElementById("gioca");
messaggio = document.getElementById("messaggio");
card = document.getElementById("card");

buttonTag.onclick = function(){
    var number;
    var number2;
    var vincita;
    var perdita;
    var parita;


    number = document.getElementById("number");
    number2 = document.getElementById("number2");
    number.innerHTML = Math.floor(Math.random() * 10)+1;
    number2.innerHTML = Math.floor(Math.random() *10) *  1;
    vincita = "complimenti, hai vinto!!"
    perdita = "mi dispiace, hai perso : ("
    parita = "parità"
    


    if(number > number2){
          messaggio.innerHTML = vincita;
          
    } else if(number < number2){
        messaggio.innerHTML = perdita;
    }
    else{
        messaggio.innerHTML = parita;
    }




}



